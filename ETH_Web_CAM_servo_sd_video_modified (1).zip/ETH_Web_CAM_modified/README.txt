ETH_Web_CAM modified project

Added:
- Servo control on GPIO16
- SD card support: CS=4, MISO=5, MOSI=6, SCLK=7
- Web buttons: SOL, ORTA, SAG, FOTO KAYDET, SD LISTELE, VIDEO BASLAT, VIDEO DURDUR
- Photos are saved as /photo_1.jpg, /photo_2.jpg, ...
- Videos are saved as /video_1.mjpeg, /video_2.mjpeg, ...

Notes:
- Web UI labels are ASCII to avoid Turkish character display problems.
- Video format is MJPEG. It is lighter for ESP32-S3 than AVI/MP4.
- Approximate recording speed is 5 FPS. If camera stream becomes slow while recording, close the live stream tab and record again.
